package com.windorland.name_generator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
